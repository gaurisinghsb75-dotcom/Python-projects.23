from flask import Flask, render_template, request
import requests
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import mean_squared_error
from datetime import datetime, timedelta
import pytz
import os

app = Flask(__name__)

API_KEY = '435ac29cc132f1fdde62995651854f9f'
BASE_URL = 'https://api.openweathermap.org/data/2.5/'

# 1. Fetch current weather
def get_current_weather(city):
    url = f"{BASE_URL}weather?q={city}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    data = response.json()
    return {
        'city': data['name'],
        'current_temp': round(data['main']['temp']),
        'feels_like': round(data['main']['feels_like']),
        'temp_min': round(data['main']['temp_min']),
        'temp_max': round(data['main']['temp_max']),
        'humidity': round(data['main']['humidity']),
        'description': data['weather'][0]['description'],
        'country': data['sys']['country'],
        'wind_gust_dir': data['wind']['deg'],
        'pressure': data['main']['pressure'],
        'Wind_Gust_Speed': data['wind']['speed'],
        'clouds': data['clouds']['all'],
        'visibility': data['visibility']
    }

# 2. Read Historical Data
def read_historical_data(filename):
    df = pd.read_csv(filename)
    df = df.dropna()
    df = df.drop_duplicates()
    return df

# 3. Prepare data for training
def prepare_data(data):
    le = LabelEncoder()
    data['WindGustDir'] = le.fit_transform(data['WindGustDir'])
    data['RainTomorrow'] = le.fit_transform(data['RainTomorrow'])
    X = data[['MinTemp', 'MaxTemp', 'WindGustDir', 'WindGustSpeed', 'Humidity', 'Pressure', 'Temp']]
    y = data['RainTomorrow']
    return X, y, le

# 4. Train the model
def train_rain_model(X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    return model

# 5. Prepare regression data
def prepare_regression_data(data, feature):
    X, y = [], []
    for i in range(len(data)-1):
        X.append(data[feature].iloc[i])
        y.append(data[feature].iloc[i+1])
    X = np.array(X).reshape(-1, 1)
    y = np.array(y)
    return X, y

# 6. Train regression model
def train_regression_model(X, y):
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)
    return model

# 7. Predict future
def predict_future(model, current_value):
    predictions = [current_value]
    for i in range(5):
        next_value = model.predict(np.array([[predictions[-1]]]))
        predictions.append(next_value[0])
    return predictions[1:]

# --- Main Route ---
@app.route('/', methods=['GET', 'POST'])
def weather_view():
    if request.method == 'POST':
        city = request.form.get('city')
        current_weather = get_current_weather(city)

        # File path for Flask (assuming file is in the same directory)
        csv_path = 'weather data.csv' 
        historical_data = read_historical_data(csv_path)
        
        X, y, le = prepare_data(historical_data)
        rain_model = train_rain_model(X, y)

        wind_deg = current_weather['wind_gust_dir'] % 360
        compass_points = [
            ("N", 0, 11.25), ("NE", 11.25, 33.75), ("E", 33.75, 56.25), ("SE", 56.25, 78.75), 
            ("S", 78.75, 101.25), ("SW", 101.25, 123.75), ("W", 123.75, 146.25), 
            ("NW", 146.25, 168.75), ("N", 168.75, 191.25), ("NE", 191.25, 213.75), 
            ("E", 213.75, 236.25), ("SE", 236.25, 258.75), ("S", 258.75, 281.25), 
            ("SW", 281.25, 303.75), ("W", 303.75, 326.25), ("NW", 326.25, 348.75),
        ]
        
        compass_direction = next(point for point, start, end in compass_points if start <= wind_deg < end)
        compass_direction_encoded = le.transform([compass_direction])[0] if compass_direction in le.classes_ else 0

        current_data = {
            'MinTemp': current_weather['temp_min'], 
            'MaxTemp': current_weather['temp_max'], 
            'WindGustDir': compass_direction_encoded, # Fixed name to match X features
            'WindGustSpeed': current_weather['Wind_Gust_Speed'], 
            'Humidity': current_weather['humidity'], 
            'Pressure': current_weather['pressure'], 
            'Temp': current_weather['current_temp']
        }

        current_df = pd.DataFrame([current_data])
        rain_prediction = rain_model.predict(current_df)[0]

        X_temp, y_temp = prepare_regression_data(historical_data, 'Temp')
        X_hum, y_hum = prepare_regression_data(historical_data, 'Humidity')

        temp_model = train_regression_model(X_temp, y_temp)
        hum_model = train_regression_model(X_hum, y_hum)

        future_temps = predict_future(temp_model, current_weather['temp_min'])
        future_humidity = predict_future(hum_model, current_weather['humidity'])

        timezone = pytz.timezone('Asia/Karachi')
        now = datetime.now(timezone)
        next_hour = now + timedelta(hours=1)
        next_hour = next_hour.replace(minute=0, second=0, microsecond=0)

        future_times = [(next_hour + timedelta(hours=i)).strftime("%H:00") for i in range(5)]

        context = {
            'city': current_weather['city'],
            'country': current_weather['country'],
            'current_temp': current_weather['current_temp'],
            'feels_like': current_weather['feels_like'],
            'MinTemp': current_weather['temp_min'],
            'MaxTemp': current_weather['temp_max'],
            'humidity': current_weather['humidity'],
            'description': current_weather['description'],
            'clouds': current_weather['clouds'],
            'wind': current_weather['Wind_Gust_Speed'],
            'pressure': current_weather['pressure'],
            'visibility': current_weather['visibility'],
            'date': datetime.now().strftime("%B %d, %Y"),
            'time1': future_times[0], 'time2': future_times[1], 'time3': future_times[2], 'time4': future_times[3], 'time5': future_times[4],
            'temp1': round(future_temps[0], 1), 'temp2': round(future_temps[1], 1), 'temp3': round(future_temps[2], 1), 'temp4': round(future_temps[3], 1), 'temp5': round(future_temps[4], 1),
            'hum1': round(future_humidity[0], 1), 'hum2': round(future_humidity[1], 1), 'hum3': round(future_humidity[2], 1), 'hum4': round(future_humidity[3], 1), 'hum5': round(future_humidity[4], 1),
        }

        return render_template('weather.html', **context)
    
    return render_template('weather.html')

if __name__ == '__main__':
    app.run(debug=True)